#include "graphics.h"

#define TAILLE_ECRAN_X 612
#define TAILLE_ECRAN_Y 612

typedef struct{ 
	int nombreCaseX, nombreCaseY;
	char cases[100][100];
	
	int LabSAVED[10];
	
	int groupeCasesAlea[25][25];
	
	POINT joueur, sortie;
	
	int nombrePastilles;
	POINT pastilles[100];
	int compteurPastillesCollectees;
	
	int nombreFantomes;
	POINT fantomes[50]; 
	POINT directionFantomes[50];
	
	BOOL sortieOuverte, fini, win;
} LABYRINTHE;

POINT piece2pixel(POINT piece, LABYRINTHE L){
	piece.x = (TAILLE_ECRAN_X/L.nombreCaseX)*piece.x;
	piece.y = (TAILLE_ECRAN_Y/L.nombreCaseY)*piece.y;
	return piece;
}

POINT pixel2piece(POINT pixel, LABYRINTHE L){
	pixel.x = pixel.x/(TAILLE_ECRAN_X/L.nombreCaseX);
	pixel.y = pixel.y/(TAILLE_ECRAN_Y/L.nombreCaseY);
	return pixel;
}

int taille_perso(LABYRINTHE L){
	if((TAILLE_ECRAN_X/L.nombreCaseX)<(TAILLE_ECRAN_Y/L.nombreCaseY)){
		return((TAILLE_ECRAN_X/L.nombreCaseX)/5);
	}
	else{
		return((TAILLE_ECRAN_Y/L.nombreCaseY)/5);
	}
}

int taille_pastille(LABYRINTHE L){
	if(L.nombreCaseX>L.nombreCaseY){
		return(((TAILLE_ECRAN_X/L.nombreCaseX)/4));
	}
	else{
		return(((TAILLE_ECRAN_Y/L.nombreCaseY)/4));
	}
}

BOOL clic_edit(POINT P){
	if(P.x > (3*TAILLE_ECRAN_X)/10 && P.x < (7*TAILLE_ECRAN_X)/10 && P.y > (6*TAILLE_ECRAN_Y)/10 && P.y < (8*TAILLE_ECRAN_Y)/10){
		return true;
	}
	return false;
}

BOOL clic_play(POINT P){
	if(P.x > (3*TAILLE_ECRAN_X)/10 && P.x < (7*TAILLE_ECRAN_X)/10 && P.y > (2*TAILLE_ECRAN_Y)/10 && P.y < (4*TAILLE_ECRAN_Y)/10)
	{
		return true;
	}
	return false;
}

BOOL clic_aleat(POINT P){
	if(P.y < TAILLE_ECRAN_Y/10){
		return true;
	}
	return false;
}

BOOL clic_edit_fini(POINT P, LABYRINTHE L){
	if(P.x > (3*TAILLE_ECRAN_X)/10 && P.x < (7*TAILLE_ECRAN_X)/10 && P.y > 0 && P.y < (TAILLE_ECRAN_Y/L.nombreCaseY) ){
		   return true;
	}
	return false;
}

void affiche_menu_principal(){
	POINT BGauche = {0,0};
	affiche_morceau_image("textures//MenuPTexture.bmp", BGauche, BGauche, 612,612);
	affiche_all();
}

void affiche_mur(POINT M, LABYRINTHE L){
	POINT Mur1,Mur2;
	COULEUR CouleurMur;
	CouleurMur = 0x3D7E0A;
	
	Mur1 = piece2pixel(M, L);
	Mur2.x = Mur1.x + (TAILLE_ECRAN_X/L.nombreCaseX);
	Mur2.y = Mur1.y + (TAILLE_ECRAN_Y/L.nombreCaseY);
	draw_fill_rectangle(Mur1,Mur2,CouleurMur);
}

void affiche_sortie(LABYRINTHE L){
	POINT Sortie1,Sortie2;
	COULEUR CouleurSortie;
	CouleurSortie = 0x3E4700;
	
	Sortie1 = piece2pixel(L.sortie, L);
	Sortie1.x = Sortie1.x + 1;
	Sortie2.x = Sortie1.x + (TAILLE_ECRAN_X/L.nombreCaseX);   Sortie2.y = Sortie1.y + (TAILLE_ECRAN_Y/L.nombreCaseY) - 1;
	
	draw_fill_rectangle(Sortie1,Sortie2,CouleurSortie);
}

void affiche_pastilles_edit(LABYRINTHE L){
	int TaillePastilles, i;
	POINT Pastilles;
	COULEUR CouleurPastilles;
	
	TaillePastilles = taille_pastille(L);
	CouleurPastilles = citronvert;
	
	for(i=0; i<L.nombrePastilles; i++){
		Pastilles.x = L.pastilles[i].x + ((TAILLE_ECRAN_X / L.nombreCaseX)/2);
		Pastilles.y = L.pastilles[i].y + ((TAILLE_ECRAN_Y / L.nombreCaseY)/2);
		draw_fill_circle(Pastilles,TaillePastilles,CouleurPastilles);
	}
}

void affiche_joueur(LABYRINTHE L){
	int TaillePersonnage;
	COULEUR CouleurPersonnage;
	CouleurPersonnage = 0xCC0000;
	POINT Pos1, Pos2;
	TaillePersonnage = taille_perso(L);
	Pos1.x = L.joueur.x - TaillePersonnage; 
	Pos1.y = L.joueur.y - TaillePersonnage; 
	
	Pos2.x = L.joueur.x + TaillePersonnage + 1; 
	Pos2.y = L.joueur.y + TaillePersonnage + 1; 
	
	draw_fill_rectangle(Pos1,Pos2,CouleurPersonnage);
}

void affiche_labyrinthe_edit(LABYRINTHE L){
	fill_screen(0x894E03);
	int TestX, TestY;
	for(TestX = 0; TestX<L.nombreCaseX; TestX++){
		for(TestY = 0; TestY<L.nombreCaseY; TestY++){
			if(L.cases[TestX][TestY] == 'm'){
				POINT Mur = {TestX,TestY};
				affiche_mur(Mur, L);
			}
		}
	}
	affiche_pastilles_edit(L);
	affiche_joueur(L);
	affiche_sortie(L);
	affiche_all();
}

void affiche_victoire(){
	POINT bg_win_text;
	bg_win_text.x = (2*TAILLE_ECRAN_X)/30;
	bg_win_text.y = (4*TAILLE_ECRAN_Y)/30;
	aff_pol("BRAVO SUPER BIEN TU AS REUSSI", 20, bg_win_text,white);
	affiche_all();
}

void affiche_defaite(){
	POINT bg_win_text;
	bg_win_text.x = (2*TAILLE_ECRAN_X)/30;
	bg_win_text.y = (4*TAILLE_ECRAN_Y)/30;
	aff_pol("perdu", 20, bg_win_text,white);
	affiche_all();
}

LABYRINTHE Zimportation_Lab(LABYRINTHE L){
	int IFichier;
	int StockeInt = 0;
	
	FILE* fichier = NULL;
	
	fichier = fopen("LabRepertoire.save","r");
	if(fichier != NULL){
		
		rewind(fichier);
		for(IFichier = 0; IFichier < 10; IFichier ++){
			if(fscanf(fichier, "%d", &StockeInt) != 1){
				printf("ERREUR LECTURE IMPOSSIBLE\n");
			}else{
				L.LabSAVED[IFichier] = StockeInt;
				printf("LECTURE REUSSIE POUR %d\n", IFichier);
				printf("%d\n", L.LabSAVED[IFichier]);
			}
			fseek(fichier,4,SEEK_CUR);
		}
		fclose(fichier);
	}
	else{
		printf("Impossible d'ouvrir ou de créer votre fichier\n");
	}
	return L;
}

void Zexportation_Lab(LABYRINTHE L){
	int EFichier;
	char LabASave[30];
	char extension[8] = ".lab";
	
	FILE* fichier = NULL;
	
	fichier = fopen("LabRepertoire.save","w+");
	if(fichier != NULL){
		rewind(fichier);
		for(EFichier = 0; EFichier < 10; EFichier ++){
			sprintf(LabASave, "%d", L.LabSAVED[EFichier]);
			strcat(LabASave,extension);
			
			fprintf(fichier,"%s\n", LabASave);
		}
		fclose(fichier);
	}
	else{
		printf("Impossible d'ouvrir ou de créer votre fichier\n");
	}
}

void suppressionLab9(LABYRINTHE L){
	int Verif;
	char fichier[30];
	char extension[8] = ".lab";
	char FlNmEx[90] = "lab//";
	sprintf(fichier, "%d", L.LabSAVED[9]);
	strcat(fichier,extension);
	strcat(FlNmEx, fichier);
	Verif = remove(FlNmEx);
	printf("%d\n\n", Verif);
}

LABYRINTHE Zsauvegarde_labyrinthe(LABYRINTHE L){
	suppressionLab9(L);
	
	int WX,WY;
	char FlNm[20];
	char extension[8] = ".lab";
	char FlNmEx[90] = "lab//";
	int temps;
	
	temps = time(NULL);
	
	sprintf(FlNm, "%i", temps);
	
	strcat(FlNm,extension);
	strcat(FlNmEx, FlNm);
	
	FILE* fichier = NULL;
	fichier = fopen(FlNmEx,"w");
	
	if(fichier != NULL){
		fprintf(fichier,"%d ; %d     %d ; %d\n%d\n%d\n", L.nombreCaseX, L.nombreCaseY,L.joueur.x, L.joueur.y, L.nombrePastilles, L.nombreFantomes);
		int WPast;
		for(WPast = 0; WPast < L.nombrePastilles; WPast++){
			fprintf(fichier,"%d ; %d\n",L.pastilles[WPast].x,L.pastilles[WPast].y);
		}
		for(WY = 0; WY < L.nombreCaseY ; WY ++){
			for(WX = 0; WX < L.nombreCaseX; WX ++){
				fprintf(fichier,"%c",L.cases[WX][L.nombreCaseY - WY - 1]);
			}
			fprintf(fichier,"\n");
		}
	}
	else{
		printf("Impossible d'ouvrir ou de créer votre fichier\n");
	}
	L.LabSAVED[9] = temps;
	fclose(fichier);
	return L;
}

LABYRINTHE Zlecture_fichier(LABYRINTHE L, char* LabAOuvrir){
	int RX, RY, Stocke1, Stocke2, Stocke3, Stocke4, Stocke5, Stocke6;
	char StockeChar;
	char extension[8] = ".lab";
	char DefNom[60] = "lab//";
	
	strcat(LabAOuvrir,extension);
	strcat(DefNom, LabAOuvrir);
	
	FILE* fichier = NULL;
	fichier = fopen(DefNom,"r");
	if(fichier != NULL){
		if(fscanf(fichier,"%d ; %d     %d ; %d\n%d\n%d\n", &Stocke1, &Stocke2, &Stocke3, &Stocke4, &Stocke5, &Stocke6) != 6){
			printf("CHARGEMENT DES 6 PREMIERES DONNEES IMPOSSIBLE\n");
		} else {
			L.nombreCaseX = Stocke1;
			L.nombreCaseY = Stocke2;
			L.joueur.x = Stocke3;
			L.joueur.y = Stocke4;
			L.nombrePastilles = Stocke5;
			L.nombreFantomes = Stocke6;
		}
		int RPast;
		for(RPast = 0; RPast < L.nombrePastilles; RPast++){
			if(fscanf(fichier,"%d ; %d\n",&Stocke1, &Stocke2) != 2){
				printf("CHARGEMENT DE LA %d eme PASTILLE IMPOSSIBLE\n", RPast + 1);
			} else{
				L.pastilles[RPast].x = Stocke1;
				L.pastilles[RPast].y = Stocke2;
			}
		}
		for(RY = 0; RY < L.nombreCaseY ; RY ++){
			for(RX = 0; RX < L.nombreCaseX; RX ++){
				if(fscanf(fichier,"%c",&StockeChar) != 1){
					printf("LECTURE DE LA CASE %d;%d IMPOSSIBLE\n", RX, L.nombreCaseY - RY - 1);
				} else{
					L.cases[RX][L.nombreCaseY - RY - 1] = StockeChar;
				}
			}
			if(fscanf(fichier,"\n") != 0){
				printf("RETOUR A LA LIGNE IMPOSSIBLE\n");
			}
		}
		fclose(fichier);
	}
	else{
		printf("Impossible d'ouvrir ou de créer votre fichier\n");
	}
	return L;
}

void affiche_bouton_edit_fini(LABYRINTHE L){
	POINT bg_play_button, hd_play_button, bg_play_text;
	bg_play_button.x = (3*TAILLE_ECRAN_X)/10;
	bg_play_button.y = 0;
	
	hd_play_button.x = (7*TAILLE_ECRAN_X)/10;
	hd_play_button.y = (TAILLE_ECRAN_Y/L.nombreCaseY);
	
	draw_fill_rectangle(bg_play_button, hd_play_button, citronvert);
	
	bg_play_text.x = bg_play_button.x + (5*TAILLE_ECRAN_Y)/30;
	bg_play_text.y = 12;
	aff_pol("Valider", 10, bg_play_text,black);
	
	affiche_all();
}

LABYRINTHE edit_labyrinthe(LABYRINTHE L, POINT clic){
	clic = pixel2piece(clic, L);
	BOOL dejaUnePastille;
	int i;
	dejaUnePastille = false;
	for(i=0; i < L.nombrePastilles; i++){
		if(clic.x == pixel2piece(L.pastilles[i], L).x && clic.y == pixel2piece(L.pastilles[i], L).y)
		{
			dejaUnePastille = true;
		}
	}
	if(clic.x == pixel2piece(L.joueur, L).x && clic.y == pixel2piece(L.joueur, L).y){
		printf("positionnement impossible");
	} else if(dejaUnePastille == true) {
		printf("positionnement impossible");
	} else if(clic.x >= L.nombreCaseX - 1 || clic.y >= L.nombreCaseY - 1 || clic.x < 1 || clic.y < 1) {
		printf("positionnement impossible");
	} else if(L.cases[clic.x][clic.y] == 'm') {
		L.cases[clic.x][clic.y] = 'v';
	} else if(L.cases[clic.x][clic.y] == 'v') {
		L.cases[clic.x][clic.y] = 'm';
	}
	return L;
}
//ICIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII





//ICIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
BOOL positionPossible(LABYRINTHE L, POINT clic){
	clic = pixel2piece(clic, L);
	if(clic.x >= L.nombreCaseX - 1 || clic.y >= L.nombreCaseY - 1 || clic.x < 1 || clic.y < 1){
		printf("\n \n cMORT \n \n");
		return false;
	}
	return true;
}

LABYRINTHE edit_joueur_position(LABYRINTHE L,POINT clic){
	clic = pixel2piece(clic, L);
	L.joueur.x = clic.x; 
	L.joueur.y = clic.y;
	L.joueur = piece2pixel(L.joueur, L);
	L.joueur.x = L.joueur.x + ( (TAILLE_ECRAN_X/L.nombreCaseX)/2);
	L.joueur.y = L.joueur.y + ( (TAILLE_ECRAN_Y/L.nombreCaseY)/2);
	return L;
}

LABYRINTHE edit_pastilles_positions(LABYRINTHE L,POINT clic, int numero){
	clic = pixel2piece(clic, L);
	L.pastilles[numero].x = clic.x; 
	L.pastilles[numero].y = clic.y;
	L.pastilles[numero] = piece2pixel(L.pastilles[numero], L);
	return L;
}

LABYRINTHE edit_fantome_directions(LABYRINTHE L){
	int compteurFantomes;
	
	for(compteurFantomes=0; compteurFantomes < L.nombreFantomes;compteurFantomes++){		
		L.directionFantomes[compteurFantomes].x = 0;
		L.directionFantomes[compteurFantomes].y = 0;
	}
	
	return L;
}

LABYRINTHE edit_fantome_position(LABYRINTHE L){
	int compteurFantomes, aleat_int_x, aleat_int_y;
	POINT CaseTest;
	BOOL pasDObstacle;
	
	for(compteurFantomes=0; compteurFantomes<L.nombreFantomes;compteurFantomes++){		
		pasDObstacle = false;
		
		while(!pasDObstacle){
			aleat_int_x = 2 + alea_int(L.nombreCaseX - 4);
			aleat_int_y = 2 + alea_int(L.nombreCaseY - 4);
			CaseTest.x = aleat_int_x;
			CaseTest.y = aleat_int_y;
			if(L.cases[aleat_int_x][aleat_int_y] == 'v' && (CaseTest.x != pixel2piece(L.joueur, L).x && CaseTest.y != pixel2piece(L.joueur, L).y)){
				pasDObstacle = true;
			}
		}		
		L.fantomes[compteurFantomes].x = aleat_int_x;
		L.fantomes[compteurFantomes].y = aleat_int_y;
		L.fantomes[compteurFantomes] = piece2pixel(L.fantomes[compteurFantomes], L);
		L.fantomes[compteurFantomes].x = L.fantomes[compteurFantomes].x + ( (TAILLE_ECRAN_X/L.nombreCaseX)/2);
		L.fantomes[compteurFantomes].y = L.fantomes[compteurFantomes].y + ( (TAILLE_ECRAN_Y/L.nombreCaseY)/2);
	}
	return L;
}

void affiche_choix_pastille(LABYRINTHE L){
	POINT aff;
	POINT BGauche = {0,0};
	
	aff.x = (TAILLE_ECRAN_X*2.4)/6; aff.y = (TAILLE_ECRAN_Y*3.7)/6;
	
	affiche_morceau_image("textures//CPastTexture.bmp", BGauche, BGauche, 612,612);
	
	aff_int(L.nombrePastilles, 95, aff, noir);
	
	affiche_all();
}

LABYRINTHE choix_pastille(LABYRINTHE L){
	BOOL fini; 
	POINT clic;
	fini = false;
	fill_screen(black);
	affiche_choix_pastille(L);
	while(!fini){
		affiche_choix_pastille(L);
		clic = wait_clic();
		if(clic.x < TAILLE_ECRAN_X/2 && clic.y > TAILLE_ECRAN_Y/3 && L.nombrePastilles > 0){
			L.nombrePastilles -= 1;
			affiche_choix_pastille(L);
		}
		else if(clic.x > TAILLE_ECRAN_X/2 && clic.y > TAILLE_ECRAN_Y/3 && L.nombrePastilles < 100){
			L.nombrePastilles += 1;
			affiche_choix_pastille(L);
		}
		else if(clic.y < TAILLE_ECRAN_Y/3){
			fini = true;
		}
	}
	return L;
}

void affiche_choix_fantomes(LABYRINTHE L){
	POINT aff;
	POINT BGauche = {0,0};
	
	aff.x = (TAILLE_ECRAN_X*2.4)/6; aff.y = (TAILLE_ECRAN_Y*3.7)/6;
	
	affiche_morceau_image("textures//CFantTexture.bmp", BGauche, BGauche, 612,612);

	aff_int(L.nombreFantomes, 95, aff, noir);
	
	affiche_all();
}

void affiche_choix_lab(LABYRINTHE L){
	POINT BGauche = {0,0};
	
	affiche_morceau_image("textures//NPartTexture.bmp", BGauche, BGauche, 612, 612);
	
	
	POINT L1D, L1G;
	L1D.x = 0; L1G.x = 612;
	L1D.y = TAILLE_ECRAN_Y/7; L1G.y = TAILLE_ECRAN_Y/7;
	draw_line(L1D,L1G,black);
	
	POINT L2D, L2G;
	L2D.x = 0; L2G.x = 612;
	L2D.y = 2*TAILLE_ECRAN_Y/7; L2G.y = 2*TAILLE_ECRAN_Y/7;
	draw_line(L2D,L2G,black);
	
	
	POINT L3D, L3G;
	L3D.x = 0; L3G.x = 612;
	L3D.y = 3*TAILLE_ECRAN_Y/7; L3G.y = 3*TAILLE_ECRAN_Y/7;
	draw_line(L3D,L3G,black);
	
	
	POINT L4D, L4G;
	L4D.x = 0; L4G.x = 612;
	L4D.y = 4*TAILLE_ECRAN_Y/7; L4G.y = 4*TAILLE_ECRAN_Y/7;
	draw_line(L4D,L4G,black);
	
	
	POINT L5D, L5G;
	L5D.x = 0; L5G.x = 612;
	L5D.y = 5*TAILLE_ECRAN_Y/7; L5G.y = 5*TAILLE_ECRAN_Y/7;
	draw_line(L5D,L5G,black);
	
	
	POINT L6H, L6B;
	L6H.x = TAILLE_ECRAN_X/2; L6B.x = TAILLE_ECRAN_X/2;
	L6H.y = 5*TAILLE_ECRAN_Y/7; L6B.y = 0;
	draw_line(L6H,L6B,black);
	
	int TexteLab;
	POINT PosPOSSIBLE[10] = { 	{10,(9*TAILLE_ECRAN_Y/14)+10}, {(TAILLE_ECRAN_X/2)+10,(9*TAILLE_ECRAN_Y/14)+10},
								{10,(7*TAILLE_ECRAN_Y/14)+10}, {(TAILLE_ECRAN_X/2)+10,(7*TAILLE_ECRAN_Y/14)+10}, 
								{10,(5*TAILLE_ECRAN_Y/14)+10}, {(TAILLE_ECRAN_X/2)+10,(5*TAILLE_ECRAN_Y/14)+10},
								{10,(3*TAILLE_ECRAN_Y/14)+10}, {(TAILLE_ECRAN_X/2)+10,(3*TAILLE_ECRAN_Y/14)+10},
								{10,(  TAILLE_ECRAN_Y/14)+10}, {(TAILLE_ECRAN_X/2)+10,(  TAILLE_ECRAN_Y/14)+10}		
							};
	
	time_t Temps;
	char TempsEcrit[200];
	
	for(TexteLab = 0; TexteLab < 10; TexteLab ++){
		Temps = L.LabSAVED[TexteLab];
		struct tm * TempsInfos = gmtime(&Temps);
		
		sprintf(TempsEcrit,"%02d/%02d/%04d %02d:%02d:%02d",
			TempsInfos->tm_mday,TempsInfos->tm_mon+1,TempsInfos->tm_year+1900,
			TempsInfos->tm_hour+2,TempsInfos->tm_min,TempsInfos->tm_sec);
		aff_pol(TempsEcrit,15,PosPOSSIBLE[TexteLab],noir);
		
		
	}
	
	affiche_all();
}


int LabClique(POINT clic, LABYRINTHE L){
	int LabFin;
	POINT L1D;
	L1D.y = TAILLE_ECRAN_Y/7;
	
	POINT L2D;
	L2D.y = 2*TAILLE_ECRAN_Y/7;
	
	POINT L3D;
	L3D.y = 3*TAILLE_ECRAN_Y/7;
	
	POINT L4D;
	L4D.y = 4*TAILLE_ECRAN_Y/7;
	
	POINT L5D;
	L5D.y = 5*TAILLE_ECRAN_Y/7;
	
	POINT L6M;
	L6M.x = TAILLE_ECRAN_X/2;
	
	if 		(clic.y <= L5D.y && clic.y >= L4D.y){
		if(		clic.x <= L6M.x){
			LabFin = 0;
		}
		else if(clic.x > L6M.x){
			LabFin = 1;
		} else{
			LabFin = 66;
		}
	}else if(clic.y <= L4D.y && clic.y >= L3D.y){
		if(		clic.x <= L6M.x){
			LabFin = 2;
		}
		else if(clic.x > L6M.x){
			LabFin = 3;
		} else{
			LabFin = 66;
		}
	}else if(clic.y <= L3D.y && clic.y >= L2D.y){
		if(		clic.x <= L6M.x){
			LabFin = 4;
		}
		else if(clic.x > L6M.x){
			LabFin = 5;
		} else{
			LabFin = 66;
		}
	}else if(clic.y <= L2D.y && clic.y >= L1D.y){
		if(		clic.x <= L6M.x){
			LabFin = 6;
		}
		else if(clic.x > L6M.x){
			LabFin = 7;
		} else{
			LabFin = 66;
		}
	}else if(clic.y <= L1D.y && clic.y >= 0){
		if(		clic.x <= L6M.x){
			LabFin = 8;
		}
		else if(clic.x > L6M.x){
			LabFin = 9;
		} else{
			LabFin = 66;
		}
	}else{
		LabFin = 66;
	}
	
	return LabFin;
}
int choix_lab(LABYRINTHE L){
	BOOL choixFait = FALSE;
	int LabChoisi;
	POINT clic;
	
	while(!choixFait){
		affiche_choix_lab(L);
		clic = wait_clic();
		LabChoisi = LabClique(clic,L);
		if(LabChoisi != 66){
			choixFait = TRUE;
		}
	}
	return LabChoisi;
}

LABYRINTHE tri_lab(LABYRINTHE L){
	int i,j;
	int tmp;
	for(i = 0; i < 10; i ++){
		for(j = i+1; j < 10; j ++){
			if(L.LabSAVED[i] < L.LabSAVED[j]){
				tmp = L.LabSAVED[i]; 
				L.LabSAVED[i] = L.LabSAVED[j];
				L.LabSAVED[j] = tmp;
			}
		}
	}
	return L;
}

LABYRINTHE choix_fantomes(LABYRINTHE L){
	BOOL fini; 
	POINT clic;
	fini = false;
	fill_screen(black);
	affiche_choix_pastille(L);
	while(!fini){
		affiche_choix_fantomes(L);
		clic = wait_clic();
		if(clic.x < TAILLE_ECRAN_X/2 && clic.y > TAILLE_ECRAN_Y/3 && L.nombreFantomes > 0){

			L.nombreFantomes -= 1;
			affiche_choix_fantomes(L);
			}
		else if(clic.x > TAILLE_ECRAN_X/2 && clic.y > TAILLE_ECRAN_Y/3 && L.nombreFantomes < 50){
			L.nombreFantomes += 1;
			affiche_choix_fantomes(L);
		}
		else if(clic.y < TAILLE_ECRAN_Y/3){
			fini = true;
		}
	}
	return L;
}
LABYRINTHE initial_alea(LABYRINTHE L){
	int initCasesX, initCasesY, GroupeX, GroupeY;
	int comptGroupe = 0;
	L = choix_pastille(L);
	L = choix_fantomes(L);
	
	for(initCasesX = 0; initCasesX < L.nombreCaseX; initCasesX++){
		for(initCasesY = 0; initCasesY < L.nombreCaseY; initCasesY++){
			if(initCasesY % 2 != 0 && initCasesX % 2 != 0){
				L.cases[initCasesX][initCasesY] = 'v';
				GroupeX = initCasesX/2;
				GroupeY = initCasesY/2;
				L.groupeCasesAlea[GroupeX][GroupeY] = comptGroupe;
				comptGroupe ++;
			} else {
				L.cases[initCasesX][initCasesY] = 'm';
			}
		}
	}
	L.cases[L.sortie.x][L.sortie.y] = 'm';
	
	int initPstX, initPstY, aleaGenPast;
	BOOL pasDeMur = false;
	
	for(aleaGenPast = 0; aleaGenPast < L.nombrePastilles; aleaGenPast ++){
		pasDeMur = false;
		while(!pasDeMur){
			initPstX = alea_int(L.nombreCaseX - 1);
			initPstY = alea_int(L.nombreCaseY - 1);
			if(L.cases[initPstX][initPstY] == 'v'){
				pasDeMur = true;
			}
		}
		L.pastilles[aleaGenPast].x = initPstX;
		L.pastilles[aleaGenPast].y = initPstY;
		L.pastilles[aleaGenPast] = piece2pixel(L.pastilles[aleaGenPast], L);
	}
	
	L.cases[L.sortie.x][L.sortie.y] = 'v';
	
	L.pastilles[L.nombrePastilles].x = 10000;
	L.pastilles[L.nombrePastilles].y = 10000;
	
	return L;
}

BOOL GroupesEgaux(LABYRINTHE L){
	int TestX, TestY;
	for(TestX = 0; TestX < 25; TestX ++){
		for(TestY = 0; TestY < 25; TestY ++){
			if(L.groupeCasesAlea[TestX][TestY] != L.groupeCasesAlea[10][10]){
				return false;
			}
		}
	}
	return true;
}

LABYRINTHE liaisonCases(LABYRINTHE L, int mereX, int mereY, int Cible){
	int CaseMX, CaseMY;
	CaseMX = (2 * mereX) + 1;
	CaseMY = (2 * mereY) + 1;
	
	if( 		Cible == 0 ){
		L.cases[CaseMX + 1][CaseMY] = 'v';
	} else if ( Cible == 1 ){
		L.cases[CaseMX - 1][CaseMY] = 'v';
	} else if ( Cible == 2 ){
		L.cases[CaseMX][CaseMY + 1] = 'v';
	} else if ( Cible == 3) {
		L.cases[CaseMX][CaseMY - 1] = 'v';
	}
	
	return L;
}

LABYRINTHE generationLabAlea(LABYRINTHE L){
	int MereX, MereY, FilleX, FilleY , Cible, GroupeFille, GroupeMere;
	int RechercheX, RechercheY;
	
	MereX = alea_int(25);
	MereY = alea_int(25);
	
	Cible = alea_int(4);
	
	POINT direction[4] = { 	{ 1	, 0 }, // droite
							{-1 , 0 }, // gauche
							{ 0 , 1 }, // haut
							{ 0 ,-1 }  // bas
						 };
						 
	FilleX = MereX + direction[Cible].x;
	FilleY = MereY + direction[Cible].y;
	
	GroupeMere  = L.groupeCasesAlea[MereX][MereY];
	GroupeFille = L.groupeCasesAlea[FilleX][FilleY];
	
	
	if(GroupeMere == GroupeFille){
		return L;
	} else if(FilleX < 0 || FilleX > 24 || FilleY < 0 || FilleY > 24){
		return L;
	} else {
		for(RechercheX = 0; RechercheX < 25; RechercheX ++){
			for(RechercheY = 0; RechercheY < 25; RechercheY ++){
				if(L.groupeCasesAlea[RechercheX][RechercheY] == GroupeFille){
					L.groupeCasesAlea[RechercheX][RechercheY] = GroupeMere;
				}
			}
		}
		L = liaisonCases(L, MereX, MereY, Cible);
	}
	return L;
}

LABYRINTHE menu_main_edit(LABYRINTHE L){ 
	int compteurPastilles, i;
	POINT clic;
	BOOL jouer, editFini, joueurPlaced, pastillesPlaced;
	compteurPastilles = 0;
	pastillesPlaced = false;
	joueurPlaced = false;
	editFini = false;
	jouer = false;
	affiche_menu_principal();
	while(!jouer){
		clic = wait_clic();
		if(clic_edit(clic)){
			L = choix_pastille(L);
			L = choix_fantomes(L);
			for(i = 0; i < L.nombrePastilles;i++){
				L.pastilles[i].x = -10;
				L.pastilles[i].y = -10;
				L.pastilles[i] = piece2pixel(L.pastilles[i], L);
			}
			printf("\n \n caEdit \n \n");
			while(!pastillesPlaced){
				affiche_labyrinthe_edit(L);
				printf("\n \n Faites un clic la ou vous souhaitez que la pastille apparaisse \n \n");
				clic = wait_clic();
				if(positionPossible(L, clic)){
					L = edit_pastilles_positions(L, clic, compteurPastilles);
					compteurPastilles++;	
				}
				if(compteurPastilles >= L.nombrePastilles)
				{
					pastillesPlaced = true;
				}
			}
			while(!joueurPlaced){
				affiche_labyrinthe_edit(L);
				printf("\n \n Faites un clic la ou vous souhaitez que le joueur apparaisse \n \n");
				clic = wait_clic();	
				if(positionPossible(L, clic)){
					L = edit_joueur_position(L, clic);	
					joueurPlaced = true;
				}
			}
			printf("\n \n Positionnez les murs \n \n");
			while(!editFini){
				affiche_labyrinthe_edit(L);
				affiche_bouton_edit_fini(L);
				clic = wait_clic();
				L = edit_labyrinthe(L, clic);
				if(clic_edit_fini(clic, L)){
					L = Zsauvegarde_labyrinthe(L);
					editFini = true;
				}
			}
			jouer = true;	
		} 
		else if(clic_play(clic)){
			char LabSelectionne[30];
			
			sprintf(LabSelectionne,"%d",L.LabSAVED[choix_lab(L)]);
			
			printf("\n \n caJoue \n \n");
			
			L = Zlecture_fichier(L, LabSelectionne);
			
			jouer = true;
		}
		else if(clic_aleat(clic)){
			L = initial_alea(L);
			printf("\n \n aleat \n \n");
			while(!GroupesEgaux(L)){
				L = generationLabAlea(L);
			}
			L = Zsauvegarde_labyrinthe(L);
			jouer = true;
		}
	}
	L = tri_lab(L);
	Zexportation_Lab(L);
	
	L.pastilles[L.nombrePastilles].x = 10000;
	L.pastilles[L.nombrePastilles].y = 10000;
	
	return L;
}

void affiche_fantomes(LABYRINTHE L){
	int TailleFantome, i;
	POINT Pos1, Pos2;
	COULEUR CouleurFantome;
	
	TailleFantome = taille_perso(L);
	CouleurFantome = 0xFF8C00;
	
	for(i=0;i<L.nombreFantomes;i++){
		Pos1.x = L.fantomes[i].x - TailleFantome; 
		Pos1.y = L.fantomes[i].y - TailleFantome; 
		
		Pos2.x = L.fantomes[i].x + TailleFantome + 1; 
		Pos2.y = L.fantomes[i].y + TailleFantome + 1; 
		
		draw_fill_rectangle(Pos1,Pos2,CouleurFantome);
	}
}

LABYRINTHE init_labyrinthe(LABYRINTHE L){
	int InitX, InitY, aleat_int_x, aleat_int_y, i;
	BOOL pasDeMur;
	L.fini = false;
	L.win = false;
	aleat_int_x = 0;
	aleat_int_y = 0;
	
	L.nombreCaseX = 51;
	L.nombreCaseY = 51;
	
	L.nombreFantomes = 10;
	L.nombrePastilles = 3;
	
	L.sortieOuverte = false;
	
	L.sortie.x = 1; 
	L.sortie.y = L.nombreCaseY - 1;
	
	L = Zimportation_Lab(L);
	L = tri_lab(L);
	
	L.compteurPastillesCollectees = 0;
	for(InitX = 0; InitX<L.nombreCaseX; InitX++){
		for(InitY = 0; InitY<L.nombreCaseY; InitY++){
			if(InitX == 0 || InitX == L.nombreCaseX - 1 || InitY == 0 || InitY == L.nombreCaseY - 1){
				L.cases[InitX][InitY] = 'm';
			}
			else{					
				L.cases[InitX][InitY] = 'v';
			}
			if(InitX == L.sortie.x && InitY == L.sortie.y)
			{
				L.cases[InitX][InitY] = 'v';
			}
		}
	}
	for(i=0; i<L.nombrePastilles; i++){
		pasDeMur = false;
		while(!pasDeMur){
			aleat_int_x = alea_int(L.nombreCaseX - 1);
			aleat_int_y = alea_int(L.nombreCaseY - 1);
			if(L.cases[aleat_int_x][aleat_int_y] == 'v'){
				pasDeMur = true;
			}
		}
		L.pastilles[i]. x = aleat_int_x;
		L.pastilles[i]. y = aleat_int_y;
		L.pastilles[i] = piece2pixel(L.pastilles[i], L);
	}
	L.cases[L.sortie.x][L.sortie.y] = 'm';
	
	L.joueur.x = TAILLE_ECRAN_X - (((TAILLE_ECRAN_X/L.nombreCaseX)*3)/2);
	L.joueur.y = ((TAILLE_ECRAN_Y/L.nombreCaseY)*3)/2;
	
	L.pastilles[L.nombrePastilles].x = 10000;
	L.pastilles[L.nombrePastilles].y = 10000;
	
	return L;
}

LABYRINTHE ouvrirSortie(LABYRINTHE L)
{
	L.sortieOuverte = true;
	L.cases[L.sortie.x][L.sortie.y] = 'v';
	return L;
}

void affiche_pastilles_jeu(LABYRINTHE L){
	int TaillePastilles;
	POINT Pastille;
	
	COULEUR CouleurPastilles;
	
	TaillePastilles = taille_pastille(L);
	CouleurPastilles = citronvert;
	
	Pastille.x = L.pastilles[L.compteurPastillesCollectees].x + ( (TAILLE_ECRAN_X/L.nombreCaseX)/2);
	Pastille.y = L.pastilles[L.compteurPastillesCollectees].y + ( (TAILLE_ECRAN_Y/L.nombreCaseY)/2);
	
	draw_fill_circle(Pastille,TaillePastilles,CouleurPastilles);
}

void affiche_labyrinthe_jeu(LABYRINTHE L){
	int TestX, TestY;
	for(TestX = 0; TestX<L.nombreCaseX; TestX++){
		for(TestY = 0; TestY<L.nombreCaseY; TestY++){
			if(L.cases[TestX][TestY] == 'm'){
				POINT Mur = {TestX,TestY};
				affiche_mur(Mur, L);
			}
		}
	}
	affiche_pastilles_jeu(L);
	affiche_fantomes(L);
	if(L.sortieOuverte == true){
		affiche_sortie(L);
	}
	else{
		affiche_mur(L.sortie, L);
	}
	affiche_joueur(L);
	affiche_all();
}

BOOL deplacement_possible(POINT directionJoueur, LABYRINTHE L){
	POINT CaseTest,Cible;
	int TestMultiDir,TaillePersonnage;
	TaillePersonnage = taille_perso(L);
	POINT DirectionTest[8] = { {(TaillePersonnage+1),0},{0,(TaillePersonnage+1)},{(-TaillePersonnage-1),0},{0,(-TaillePersonnage-1)},{(TaillePersonnage+1),(TaillePersonnage+1)},{(-TaillePersonnage-1),(TaillePersonnage+1)},{(TaillePersonnage+1),(-TaillePersonnage-1)},{(-TaillePersonnage-1),(-TaillePersonnage-1)} };
	
	for(TestMultiDir = 0; TestMultiDir < 8;TestMultiDir ++){
		Cible = DirectionTest[TestMultiDir];
		CaseTest.x = directionJoueur.x + L.joueur.x + Cible.x;			
		CaseTest.y = directionJoueur.y + L.joueur.y + Cible.y;
		CaseTest = pixel2piece(CaseTest, L);
		if(L.cases[CaseTest.x][CaseTest.y] == 'm'){
			return false;
		}
	}
	return true;
}

BOOL deplacement_possible_fantome(POINT directionJoueur, POINT fantome, LABYRINTHE L, int fantomeNumero){
	POINT CaseTest,Cible;
	int TestMultiDir,TaillePersonnage;
	TaillePersonnage = taille_perso(L);
	POINT DirectionTest[8] = { {(TaillePersonnage+1),0},{0,(TaillePersonnage+1)},{(-TaillePersonnage-1),0},{0,(-TaillePersonnage-1)},{(TaillePersonnage+1),(TaillePersonnage+1)},{(-TaillePersonnage-1),(TaillePersonnage+1)},{(TaillePersonnage+1),(-TaillePersonnage-1)},{(-TaillePersonnage-1),(-TaillePersonnage-1)} };
	
	for(TestMultiDir = 0; TestMultiDir < 8;TestMultiDir ++){
		Cible = DirectionTest[TestMultiDir];
		CaseTest.x = directionJoueur.x + fantome.x + Cible.x;			
		CaseTest.y = directionJoueur.y + fantome.y + Cible.y;
		CaseTest = pixel2piece(CaseTest, L);
		if(L.cases[CaseTest.x][CaseTest.y] == 'm' || (CaseTest.x == L.sortie.x && CaseTest.y == L.sortie.y)){
			return false;
		}
	}
	return true;
}

LABYRINTHE deplace_joueur(POINT directionJoueur, LABYRINTHE L){
	if(deplacement_possible(directionJoueur,L)){
		L.joueur.x = L.joueur.x + directionJoueur.x;
		L.joueur.y = L.joueur.y + directionJoueur.y;
	}
	return L;
}

LABYRINTHE deplace_fantomes(LABYRINTHE L){
	int i;
	BOOL deplaced;
	POINT DirectionTest[4] = { {1,0},{0,1},{-1,0},{0,-1} };
	for(i=0; i<L.nombreFantomes;i++){
		deplaced = false;
		while(!deplaced){
			if(L.directionFantomes[i].x == 0 && L.directionFantomes[i].y == 0){
				L.directionFantomes[i] = DirectionTest[alea_int(4)];
			}
			else if(deplacement_possible_fantome(L.directionFantomes[i], L.fantomes[i], L, i)){
				L.fantomes[i].x = L.fantomes[i].x + L.directionFantomes[i].x;
				L.fantomes[i].y = L.fantomes[i].y + L.directionFantomes[i].y;
				deplaced = true;
			}
			else{
				L.directionFantomes[i] = DirectionTest[alea_int(4)];
			}
		}
	}
	return L;	
}

LABYRINTHE jeu_fini(LABYRINTHE L){
	int i, j, intervalleXPlus, intervalleXMoins, intervalleYPlus, intervalleYMoins, TaillePerso;
	TaillePerso = taille_perso(L);
	
	
	POINT DirectionTest[8] = { {(TaillePerso+1),0},{0,(TaillePerso+1)},{(-TaillePerso-1),0},{0,(-TaillePerso-1)},{(TaillePerso+1),(TaillePerso+1)},{(-TaillePerso-1),(TaillePerso+1)},{(TaillePerso+1),(-TaillePerso-1)},{(-TaillePerso-1),(-TaillePerso-1)} };
	
	if(pixel2piece(L.joueur, L).x == L.sortie.x &&  pixel2piece(L.joueur, L).y == L.sortie.y){
		L.fini = true;
		L.win = true;
		return L;
	}
	else{
		for(i=0; i < L.nombreFantomes; i++){
			for(j=0; j < 8; j++){
				intervalleXPlus = L.fantomes[i].x + TaillePerso;
				intervalleXMoins = L.fantomes[i].x - TaillePerso;
				intervalleYPlus = L.fantomes[i].y + TaillePerso;
				intervalleYMoins = L.fantomes[i].y - TaillePerso;
				if(L.joueur.x + DirectionTest[j].x >= intervalleXMoins && L.joueur.x + DirectionTest[j].x <= intervalleXPlus && L.joueur.y + DirectionTest[j].y >= intervalleYMoins && L.joueur.y + DirectionTest[j].y <= intervalleYPlus){
					L.fini = true;
					L.win = false;
					return L;
				}
				else{
					L.fini = false;
					L.win = false;
				}
			}
		}
	}
	return L;
}

void fps(){
	int Delay;
	Delay = (TAILLE_ECRAN_X+TAILLE_ECRAN_Y)/1000;
	SDL_Delay(Delay);
}

BOOL toutesPastillesCollectees(LABYRINTHE L){
	if(L.compteurPastillesCollectees == L.nombrePastilles){
		return true;
	}
	return false;
}

BOOL pastilleCollectee(LABYRINTHE L){
	int j, intervalleXPlus, intervalleXMoins, intervalleYPlus, intervalleYMoins, TaillePerso;
	
	TaillePerso = taille_perso(L);
	
	POINT DirectionTest[8] = {  {(TaillePerso+1)	,0					},
								{0					,(TaillePerso+1)	},
								{(-TaillePerso-1)	,0					},
								{0					,(-TaillePerso-1)	},
								{(TaillePerso+1)	,(TaillePerso+1)	},
								{(-TaillePerso-1)	,(TaillePerso+1)	},
								{(TaillePerso+1)	,(-TaillePerso-1)	},
								{(-TaillePerso-1)	,(-TaillePerso-1)	}
							 };

	for(j=0; j < 8; j++){
		intervalleXPlus = L.pastilles[L.compteurPastillesCollectees].x + TaillePerso + ( (TAILLE_ECRAN_X/L.nombreCaseX)/2);
		intervalleXMoins = L.pastilles[L.compteurPastillesCollectees].x - TaillePerso + ( (TAILLE_ECRAN_X/L.nombreCaseX)/2);
		intervalleYPlus = L.pastilles[L.compteurPastillesCollectees].y + TaillePerso + ( (TAILLE_ECRAN_Y/L.nombreCaseY)/2);
		intervalleYMoins = L.pastilles[L.compteurPastillesCollectees].y - TaillePerso + ( (TAILLE_ECRAN_Y/L.nombreCaseY)/2);
		if(L.joueur.x + DirectionTest[j].x >= intervalleXMoins && L.joueur.x + DirectionTest[j].x <= intervalleXPlus && L.joueur.y + DirectionTest[j].y >= intervalleYMoins && L.joueur.y + DirectionTest[j].y <= intervalleYPlus){
			return true;
		}
	}
	return false;
}

int main(){
	LABYRINTHE L; 
	POINT directionJoueur;
	
	init_graphics(TAILLE_ECRAN_X,TAILLE_ECRAN_Y);
	fill_screen(0x765154);
	affiche_auto_off();
	
	L = init_labyrinthe(L);
	L = menu_main_edit(L);
	L = edit_fantome_position(L);
	L = edit_fantome_directions(L);
	
	affiche_labyrinthe_jeu(L);
	while(!L.fini){
		fps();
		fill_screen(0x59330F);
		directionJoueur = get_arrow();
		L = deplace_joueur(directionJoueur, L);
		L = deplace_fantomes(L);
		if(pastilleCollectee(L)){
			L.compteurPastillesCollectees++;
		}
		if(toutesPastillesCollectees(L)){
			L = ouvrirSortie(L);
		}
		affiche_labyrinthe_jeu(L);
		L = jeu_fini(L);
	}
	if(L.win){
		affiche_victoire();
	}
	else{
		affiche_defaite();
	}
	affiche_all();
	Zexportation_Lab(L);
	wait_escape();
	exit(0);
}
